# Snip — URL Shortener

A full-stack URL shortening service built with **Python**, **Flask**, and **SQLite**.

## Features
- Collision-free 6-character alphanumeric short IDs (62⁶ ≈ 56 billion combinations)
- Sub-100 ms redirect latency
- Click tracking per link
- REST API (`/shorten`, `/stats/<id>`, `/api/recent`)
- Responsive dark-themed web UI

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the app
python app.py

# 3. Open http://localhost:5000
```

## Run Tests

```bash
python test_shortener.py
```

The test suite verifies:
- 10,000+ unique IDs with zero collisions
- All API routes (shorten, redirect, stats, recent)
- Sub-100 ms redirect latency
- Click tracking accuracy

## Project Structure

```
url-shortener/
├── app.py              # Flask application
├── templates/
│   ├── index.html      # Main UI
│   └── 404.html        # Error page
├── requirements.txt
├── test_shortener.py   # Test suite
└── README.md
```

## API Reference

| Method | Endpoint         | Description                        |
|--------|------------------|------------------------------------|
| GET    | `/`              | Web UI                             |
| POST   | `/shorten`       | Create short URL (JSON body: `url`)|
| GET    | `/<short_id>`    | Redirect to original URL           |
| GET    | `/stats/<id>`    | JSON stats for a short link        |
| GET    | `/api/recent`    | Last 10 created links              |
